package be.helha.aemt.groupeA6.config;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/groupeA6")
public class RestService extends Application {
	
}
