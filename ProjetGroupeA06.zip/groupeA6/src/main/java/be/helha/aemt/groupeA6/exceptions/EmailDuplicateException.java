package be.helha.aemt.groupeA6.exceptions;

public class EmailDuplicateException extends Exception {
	
    public EmailDuplicateException(String message) {
        super(message);
    }
}
