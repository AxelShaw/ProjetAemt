package be.helha.aemt.groupeA6.exceptions;

public class NotFoundException extends Exception{
	public NotFoundException()
	{
		super("Probleme dans la reception des donnees");
	}
}
