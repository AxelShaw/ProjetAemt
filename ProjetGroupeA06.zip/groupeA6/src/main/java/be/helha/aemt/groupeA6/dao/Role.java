package be.helha.aemt.groupeA6.dao;

public interface Role {
	public abstract int getPerm();
}
